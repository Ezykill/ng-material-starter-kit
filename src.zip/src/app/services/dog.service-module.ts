import { NgModule } from '@angular/core';
import { DogService } from './dog.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [DogService],
  exports: []
})
export class DogServiceModule {
}
