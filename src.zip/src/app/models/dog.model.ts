export interface DogModel {

  readonly breed: string;
  readonly cityId: string;
  readonly id: string;
}
